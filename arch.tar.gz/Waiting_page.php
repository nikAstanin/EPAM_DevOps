	<!DOCTYPE html>
<html>
	<head>
	<meta charset = "UTF-8"/>
	<link rel = "stylesheet" href = "style/Main_style.css"/>
	<title>Lab_4</title>
	<script src="scripts/Main_script.js"></script>
	</head>
	
	<body onload = "timer()">

<?php include 'header.php'; ?>
			
			<main>
				<p>TEST</p><br>
				Seconds:<span id = "count">0</span>
			</main>
			
<?php include 'footer.php'; ?>