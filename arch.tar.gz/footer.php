<footer>
				<ul id = "menu">
					<li><a href = "index.php">&nbsp > ГЛАВНАЯ СТРАНИЦА</a></li>
					<li><a href = "Form.php">&nbsp > НОВОСТИ</a></li>
					<li><a href = "Waiting_page.php">&nbsp > О ФИРМЕ</a></li>
					<li><a href = "Variables.php">&nbsp > ПРАЙС-ЛИСТ</a></li>
					<li><a href = "FormWithPHP.php">&nbsp > КАРТА САЙТА</a></li>
					<li><a href = "Farm.php">&nbsp > НОВЫЕ ВАКАНСИИ</a></li>
					<li><a href = "JQueryForm.php">&nbsp > ПОДПИСКА</a></li>
					<li><a href = "Ticks.php">&nbsp > ИНТЕРНЕТ МАГАЗИН</a></li>
					<li><a href = "#">&nbsp > ФАРМ-НАВИГАТОР</a></li>
					<li><a href = "#">&nbsp > КАК К НАМ ПРОЕХАТЬ</a></li>
				</ul>
			</footer>
		</div>
	</body>
</html>