		<div id="wrapper">
			<header>
				<div id = "logo_image" onclick="logo_click(this)">
					<img src="img/Logo.jpg">
				</div>
				<div id = "Podpiska_logo">
					<a href = "#"><img src="img/Podpiska.jpg"></a>
					<p id = "Podpiska">подписка</p>
				</div>
				<div id = "Price_logo">
					<a href = "#"><img src="img/Price.jpg"></a>
					<p id = "Price">прайс</p>
				</div>
				<div id = "Zakaz_logo">
					<a href = "#"><img src="img/Zakaz.jpg"></a>
					<p id = "Zakaz">заказы</p>
				</div>
				<div id = "Magazin_logo">
					<a href = "#"><img src="img/Magazin.jpg"></a>
					<p id = "Magazin">интернет-магазин</p>
				</div>
				<div id = "Otchet_logo">
					<a href = "#"><img src="img/Otchet.jpg"></a>
					<p id = "Otchet">отчеты</p>
				</div>
				
				<div id = "Login">
					<span>ЛОГИН</span>
					<input id = "Login_field",  type="text">
				</div>
				<div id = "PSWD">
					<span>ПАРОЛЬ</span>
					<input id = "Pswd_field",  type="text">
				</div>
				<button id = "btn">ВОЙТИ</button>
				
				<div id = "right_block">
					<p id = "Gazeta"><a href = "#">ГАЗЕТА ></a></p>
					<p id = "Tovar"><a href = "#">ТОВАРЫ ></a></p>
					<p id = "Partner"><a href = "#">ПАРТНЕРЫ ></a></p>
					<p id = "Podpis"><a href = "#">ПОДПИСКА ></a></p>
					<p id = "Registration"><a href = "#">РЕГИСТРАЦИЯ ></a></p>
				</div>
			</header>